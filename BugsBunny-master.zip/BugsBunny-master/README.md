# BugsBunny
PROBLEM STATEMENT Data base consisting of the details of an Outbreak in an area, the morbidity, mortality, the reparative and managemental measures adapted in controlling the disease, the diagnostic procedures or vaccination regimen followed shall serve as guide to sellers or buyers who come to that particular geographical area for livestock purchasing or migration from different place. The road, rail and see routes, the automobiles owners shall be alerted when they traverse through these areas for additional precautionary measures to curb the further spread of the disease. Used, Death, Birth, Census- Culled animals, Zoonotic incidences, (Text alerts to people and areas tangent the area of OBR), could be useful to prevent further recurrence and spread of zoonotic diseases, with potential to cause human deaths. The incidences could be recorded as zoonotic disease data base with particulars about number of human deaths occurred in area for future reference and guidance to design suitable policies. The information about diseases shall be published for public opinion and acceptance. For example, information published on the occurrence of Anthrax in sheep would alert other animal owners. This data base shall be linked with census data base, so that status of deaths during an outbreak shall be in the notice of the public. Thus unvaccinated animal owners shall be alerted through text messages to take-up vaccinations, so that further outbreaks may be averted. Problem Data Set can be: Animal Husbandry Departmental Animal disease diagnostic laboratories have relevant data.

BASIC IDEOLOGY 1.Our idea is to create three databases which hold the records of the follows : ◦ Database for Newly discovered Diseases, its treatment and its cure. ◦ Database of Pet Owners and Pet shop owners in which they will register themselves. ◦ Database of Doctors in which all the doctors register themselves. 2. There will be a section where Verified Doctors will give regular update as their post about Diseases and its precaution . 3. Whenever any new Disease is discover there will be a POP-UP in contact details of doctors and owners which was registered. 4. There will be a chat server for Doctors and owners for interaction between them . 5. There will also a Warning POP-UP whenever any chronic disease is spreading.

TECH STACK • FRONT END • HTML • CSS • JAVA SCRIPT • JQUERY • JSON

• DATABASE
• MY SQL

• BACK END
• PYTHON
• DJANGO
• PHP 
• AJAX
USE CASES 1. LABORATORIES: • This is the place where the new diseases is discover. • They will provide all the necessary details about the diseases like treatment, medicines, how to cure, etc. • They will send all the information to the NADRS. 2. National Animal Diseases Reporting System (NADRS): • They will first verify the report. • Then they will send report to the registered doctors and owners. 3. Doctors: • They get regular update so that the doctor gets aware from that disease. • They can also post some useful information’s to the post section. • They can also give some advise through the chat server to the owners.
